import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Category } from './model/Category';
import { Product } from './model/Product';
import { User } from './model/User';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categoryStatus: boolean
  adminStatus: boolean
  currentUser: User
  productStatus: boolean
  public products: Product[]
  public categorys: Category[]

  public constructor(public http: HttpClient) {
    this.categoryStatus = false
    this.categorys = []
    this.productStatus = false
    this.products = []
  }
  
  addCategory(category: Category) {
    return this.http.post('http://localhost:' + environment.port + '/grocery/category/save', category, httpOptions)
  }
  getCategory() {
    return this.http.get('http://localhost:' + environment.port + '/grocery/category/all', httpOptions)
  }
  deleteCategory(cid: number) {
    return this.http.delete('http://localhost:' + environment.port + '/grocery/category/delete/' + cid, httpOptions)
  }





}
