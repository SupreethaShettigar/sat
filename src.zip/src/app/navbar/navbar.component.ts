import { AuthenticateService } from './../authenticate.service';
import { Component, OnInit } from '@angular/core';
import { Status } from '../model/Status';
import { User } from '../model/User';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { CategoryService } from '../category.service';
import { Category } from './../model/Category';
import { ProductService } from '../product.service';
import { Product } from './../model/Product';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  categorys: Category[]
  progressFlag: boolean
  constructor(public authService: AuthenticateService, public router: Router, public catService: CategoryService, public proService: ProductService,public cartService:CartService ) {

    this.catService.getCategory()
      .subscribe((res: Category[]) => {
        if (res) {
          this.categorys = res
          this.catService.categorys = res
        }

        this.progressFlag = false

      })

  }

  ngOnInit() {
  }

  signOut() {
    this.authService.signOut()
      .subscribe((res: Status) => {
        if (res.queryStatus) {
          this.authService.loginStatus = false
          this.router.navigateByUrl('/signin')
        }
      })
  }
  
  productbyCategory(cid: number) {
    this.progressFlag = true
    this.proService.productbyCategory(cid)
      .subscribe((res: Product[]) => {
        console.log(res)
        if (res) {
          this.proService.productcat = res
          this.proService.productcat.map(p => p.uqty = 0)
          this.router.navigateByUrl('/Viewproduct')
        }

        this.progressFlag = false

      })
  }
getCartByUid(uid:number)
{
  this.progressFlag=true
  this.cartService.getCartByUid(uid)
  .subscribe((res: Cart[]) => {
    console.log(res)
    if (res) {
      this.cartService.carts = res
      
      this.router.navigateByUrl('/cart')
    }

    this.progressFlag = false

  })
}

}
