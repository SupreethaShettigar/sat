export interface Comment{
    commentId: number
    commentText: string
    fk:number
    ufk:number
}