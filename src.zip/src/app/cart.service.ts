import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Category } from './model/Category';
import { Product } from './model/Product';
import { User } from './model/User';
import { environment } from '../environments/environment';
import { Cart } from './model/Cart';
import { Order } from './model/Order';


const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class CartService {
  currentUser: User
  carts:Cart[]
  constructor(public http: HttpClient) { 

  }
  addToCart(cart: Cart)
  {
    return this.http.post('http://localhost:' + environment.port + '/grocery/cart/save', cart, httpOptions)
  }
  getCartByUid(uid:number)
  {
    return this.http.get('http://localhost:'+environment.port+'/grocery/cart/all/'+uid, httpOptions)
  }

  deleteCartItem(cartid: number) {
    return this.http.delete('http://localhost:' + environment.port + '/grocery/cart/delete/' + cartid, httpOptions)
  }
placeOrder(order:Order)
{
  return this.http.post('http://localhost:' + environment.port + '/grocery/order/add', order, httpOptions)
}
  
}
